from django.shortcuts import render
from inventario.models import Cafe
from django.shortcuts import redirect

# Create your views here.
def restarInventario (request):
	if request.method == "GET":

		cafeActual = Cafe.objects.get(id=request.GET['id'])
		cafeActual.Stock = cafeActual.Stock - 1
		cafeActual.save();

		return redirect('listado')