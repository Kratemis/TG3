//definir que tipo de bases de datos se va a usar
var mongo = require('mongodb');
var Server = mongo.Server,
    Db = mongo.Db,
    BSON = mongo.BSONPure;

//definir el servidor de la db
var server = new Server('localhost', 27017, {auto_reconnect: true});
db = new Db('cafedb', server, {safe: true});

//nueva conexion a la base de datos
db.open(function(err, db) {
    if(!err) {
        console.log("Connected to 'cafedb' database");
        db.collection('cafes', {safe:true}, function(err, collection) { //conectamos con la coleccion
            if (err) {
                // no existe la coleccion
                console.log("The 'cafes' collection doesn't exist. Creating it with sample data...");
               // populateDB(); //ponemos datos de prueba en la coleccion
            }
        });
    }
});

//fucnion que busca en la base de datos un cafe por ID
exports.findById = function(req, res) {
    var id = req.params.id; //pillamos el id
    console.log('Retrieving cafe: ' + id);
    db.collection('cafes', function(err, collection) {
        collection.findOne({'_id':new BSON.ObjectID(id)}, function(err, item) {  //buscamos en la db ese id
            res.send(item); //mandamos el objeto json
        });
    });
};

//funcion que devuelve todos los cafes de la db
exports.findAll = function(req, res) {
    db.collection('cafes', function(err, collection) {
        collection.find().toArray(function(err, items) {
            res.send(items);
        });
    });
};

exports.ventas = function(req, res) {
    db.collection('cafes', function(err, collection) {
        collection.find().toArray(function(err, items) {
            res.send(items);
        });
    });
};

exports.addCafe = function(req, res) {
    var cafe = req.body;
    console.log('Adding cafe: ' + JSON.stringify(cafe));
    db.collection('cafes', function(err, collection) {
        collection.insert(cafe, {safe:true}, function(err, result) {
            if (err) {
                res.send({'error':'An error has occurred'});
            } else {
                console.log('Success: ' + JSON.stringify(result[0]));
                res.send(result[0]);
            }
        });
    });
}

exports.updateCafe = function(req, res) {
    var id = req.params.id;
    var cafe = req.body;
    delete cafe._id;
    console.log('Updating cafe: ' + id);
    console.log(JSON.stringify(cafe));
    db.collection('cafes', function(err, collection) {
        collection.update({'_id':new BSON.ObjectID(id)}, cafe, {safe:true}, function(err, result) {
            if (err) {
                console.log('Error updating cafe: ' + err);
                res.send({'error':'An error has occurred'});
            } else {
                console.log('' + result + ' document(s) updated');
                res.send(cafe);
            }
        });
    });
}

//servicio REST que consume
exports.updateConsumir = function(req, res) {
    var id = req.params.id; //id del cafe
    var usuario = req.params.usuario; //usuario que lo consume
    

   db.collection('cafes', function(err, collection) {
        collection.findOne({'_id':new BSON.ObjectID(id)}, function(err, item) {
            
            if (item.stock == 0)
            {
                res.send({'error':'An error has occurred'});
                return;
            }
            console.log('Consumiendo cafe: ' + item.id);
        
            item.stock = item.stock -1;
            delete item._id;
            console.log(JSON.stringify(item));

            db.collection('cafes', function(err, collection) {
                    collection.update({'_id':new BSON.ObjectID(id)}, item, {safe:true}, function(err, result) {
                        if (err) {
                            console.log('Error updating cafe: ' + err);
                            res.send({'error':'An error has occurred'});
                        } else {
                            console.log('' + result + ' document(s) updated');
                            res.send(item);
                        }
                    });
                });







        });
    }); 


}


exports.deleteCafe = function(req, res) {
    var id = req.params.id;
    console.log('Deleting cafe: ' + id);
    db.collection('cafes', function(err, collection) {
        collection.remove({'_id':new BSON.ObjectID(id)}, {safe:true}, function(err, result) {
            if (err) {
                res.send({'error':'An error has occurred - ' + err});
            } else {
                console.log('' + result + ' document(s) deleted');
                res.send(req.body);
            }
        });
    });
}

/*--------------------------------------------------------------------------------------------------------------------*/
// Populate database with sample data -- Only used once: the first time the application is started.
// You'd typically not find this code in a real-life app, since the database would already exist.
var populateDB = function() {

    var cafes = [
    {

        name: "Te de marrakect",
        stock: "0",
        picture: "marrakesh.jpg",
        description: "balblablablba"
    },
    {
        name: "con leche",
        stock: "0",
        picture: "generic.jpg",
        description: "balblablablba"
    },
    {
        name: "largo",
        stock: "0",
        picture: "generic.jpg",
        description: "balblablablba"
    }];

    db.collection('cafes', function(err, collection) {
        collection.insert(cafes, {safe:true}, function(err, result) {});
    });

};


