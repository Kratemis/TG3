var express = require('express'),
    path = require('path'),
    http = require('http'),
    cafe = require('./routes/cafes');

var app = express();

app.configure(function () {
    app.set('port', process.env.PORT || 3000);
    app.use(express.logger('dev'));  /* 'default', 'short', 'tiny', 'dev' */
    app.use(express.bodyParser()),
    app.use(express.static(path.join(__dirname, 'public')));
});

app.get('/cafes', cafe.findAll);
app.get('/ventas', cafe.ventas);
app.get('/cafes/:id', cafe.findById);
app.post('/cafes', cafe.addCafe);
app.put('/cafes/:id', cafe.updateCafe);
app.put('/cafesConsumir/:id/:usuario/:stock', cafe.updateConsumir);
app.delete('/cafes/:id', cafe.deleteCafe);

http.createServer(app).listen(app.get('port'), function () {
    console.log("Express server listening on port " + app.get('port'));
});
