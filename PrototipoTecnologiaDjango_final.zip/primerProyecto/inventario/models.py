from django.db import models

# Create your models here.
class Cafe(models.Model):
	Nombre = models.CharField(max_length=100)
	Foto = models.CharField(max_length=200)
	Stock = models.IntegerField()
	Descripcion = models.TextField()	




