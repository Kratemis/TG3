from django.apps import AppConfig


class SumarstockConfig(AppConfig):
    name = 'sumarstock'
