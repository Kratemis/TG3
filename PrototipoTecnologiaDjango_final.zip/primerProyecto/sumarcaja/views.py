from django.shortcuts import render
from inventario.models import Cafe
from django.shortcuts import redirect
# Create your views here.
def sumarcaja (request):
	if request.method == "GET":

		cafeActual = Cafe.objects.get(id=request.GET['id'])
		cafeActual.Stock = cafeActual.Stock + 16
		cafeActual.save();

		return redirect('/stock/')