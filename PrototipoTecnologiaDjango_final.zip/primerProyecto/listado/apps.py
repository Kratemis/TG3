from django.apps import AppConfig


class ListadoConfig(AppConfig):
    name = 'listado'
