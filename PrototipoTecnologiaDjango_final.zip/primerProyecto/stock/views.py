from django.shortcuts import render_to_response
from inventario.models import Cafe

# Create your views here.
def stock (request):
	listado_cafe = Cafe.objects.order_by('Nombre')
	return render_to_response('stock.html', {'listado_cafe': listado_cafe})