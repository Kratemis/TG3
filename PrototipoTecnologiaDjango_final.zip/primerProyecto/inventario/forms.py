from django import forms
 
class CafeForm(forms.Form):
	Nombre = forms.CharField(max_length=100)
	Foto = forms.CharField(max_length=200)
	Stock = forms.CharField(max_length=100)
	Descripcion = forms.CharField(widget=forms.Textarea)#campo de tipo textarea 
