from django.apps import AppConfig


class SumarcajaConfig(AppConfig):
    name = 'sumarcaja'
