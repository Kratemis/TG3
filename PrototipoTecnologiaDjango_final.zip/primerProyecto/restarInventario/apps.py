from django.apps import AppConfig


class RestarinventarioConfig(AppConfig):
    name = 'restarInventario'
