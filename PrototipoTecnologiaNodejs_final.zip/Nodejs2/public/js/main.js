var AppRouter = Backbone.Router.extend({


// especifica la ruta del navegador y la funcion que se ejecutara para cargar la vista
    routes: {
        ""                  : "list",
        "cafes"	: "list",
        "cafes/page/:page"	: "list",
        "cafes/add"         : "addCafe",
        "cafes/:id"         : "cafeDetails",
        "about"             : "about",
        "cafesConsumir/:id/:usuario/:stock"             : "consumirC",
        "ventas"            : "ventas"
    },

    // cargar la vista del navbar (la barra navegacion)
    initialize: function () {
        this.headerView = new HeaderView();
        $('.header').html(this.headerView.el);
    },


    // cargar la vista principal (mostrara los cafes)
	list: function(page) {
        //calcular las paginas
        var p = page ? parseInt(page, 10) : 1;
        var cafeList = new CafeCollection();
        cafeList.fetch({success: function(){
            $("#content").html(new CafeListView({model: cafeList, page: p}).el);
        }});
        this.headerView.selectMenuItem('home-menu');
    },

    // cargar la vista de ver en detalle un cafe
    cafeDetails: function (id) {
        //obtener el cafe
        var cafe = new Cafe({_id: id});
        cafe.fetch({success: function(){
            $("#content").html(new CafeView({model: cafe}).el);
        }});
        this.headerView.selectMenuItem();
    },

    // cargar la vista de añadir cafe
	addCafe: function() {
        var cafe = new Cafe();
        $('#content').html(new CafeView({model: cafe}).el);
        this.headerView.selectMenuItem('add-menu');
	},

    about: function () {
        if (!this.aboutView) {
            this.aboutView = new AboutView();
        }
        $('#content').html(this.aboutView.el);
        this.headerView.selectMenuItem('about-menu');
    },

        home: function (id) {
        if (!this.homeView) {
            this.homeView = new HomeView();
        }
        $('#content').html(this.homeView.el);
        this.headerView.selectMenuItem('home-menu');
    },

    consumirC: function (id,usuario,stock) {
        consumir (id,usuario,stock);
    },

    ventas: function() {

        var ventaList = new VentaCollection();
        cafeList.fetch({success: function(){
            $("#content").html(new CafeListView({model: cafeList, page: p}).el);
        }});
        this.headerView.selectMenuItem('home-menu');
    }
});

utils.loadTemplate(['HomeView', 'HeaderView', 'CafeView', 'CafeListItemView', 'AboutView'], function() {
    app = new AppRouter();
    Backbone.history.start();
});
















function consumir (id)
{
    window.id = id;
    swal({
          title: "Introduce el nombre del consumidor",
          text: "Nombre:",
          type: "input",
          showCancelButton: true,
          closeOnConfirm: false,
          animation: "slide-from-top",
          inputPlaceholder: "name.."
        },
        function(inputValue){
          if (inputValue === false) return false;
          
          if (inputValue === "") {
            swal.showInputError("Escribe algo!");
            return false
          }

          cons(window.id,inputValue); //llamar a la fucnion que utilzia REST
            
          
          
  //swal("Nice!", "You wrote: " + inputValue + "----------" + window.id, "success");
});

}






            
// funcion llamda cuando consumimos un cafe
function cons(id, inputValue) {
    //creamos una peticion al servicio REST
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (xhttp.readyState == 4 && xhttp.status == 200) { // si el resultado de la peticion es exitosa (200)
     
    }
    else
    {


        error();

          
    }
  };
  //enviar la peticion PUT al servicio REST implementado
  xhttp.open("PUT", "http://localhost:3000/cafesConsumir/"  + window.id + "/" + inputValue +"/"     + "19" , true);
  xhttp.send();
} 


function error()
{

        swal({
              type: "error",
              title: "Error",
              text: "No puedes consumir este café, no tiene stock."

        });

}